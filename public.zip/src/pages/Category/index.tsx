import React from 'react'

type Props = {}

const Category = (props: Props) => {
    console.log('category')
    return (
        <div>Category</div>
    )
}

export default Category