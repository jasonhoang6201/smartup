import React from 'react'
import './ProductDetail.scss'

type Props = {}

const ProductDetail = (props: Props) => {
    return (
        <div>ProductDetail</div>
    )
}

export default ProductDetail