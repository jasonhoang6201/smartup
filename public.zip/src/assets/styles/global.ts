export const BASE_COLOR = {
    rhythm: '#726E8D',
    darkGunmetal: '#22202E'
}