import React from 'react'

type Props = {}

const LoadingScreen = (props: Props) => {
    return (
        <div>LoadingScreen</div>
    )
}

export default LoadingScreen