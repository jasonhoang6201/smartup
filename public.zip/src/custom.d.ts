declare module "*.svg" {
    const content: any;
    export default content;
}
declare module '*.jpg';
declare module '*.png';
declare module '*.jpeg';